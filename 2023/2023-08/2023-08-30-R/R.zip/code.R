data <- read.csv("etf.csv")

# Q1
summary(data)
plot(data$H0A0, data$JNK)

correlation_test <- cor.test(data$H0A0, data$JNK)

print(correlation_test)

# 拟合简单线性回归模型
model <- lm(H0A0 ~ JNK, data=data)

# 绘制残差与拟合值的散点图
plot(model$fitted.values, model$residuals, xlab="Fitted Values", ylab="Residuals",
     main="Residuals vs Fitted Values")

# 绘制残差的正态 Q-Q 图
qqnorm(model$residuals, main="Normal Q-Q Plot of Residuals")
qqline(model$residuals)

# 计算杠杆值（Leverage）
leverages <- hatvalues(model)
barplot(leverages, names.arg=rownames(data), xlab="Observation", ylab="Leverage",
        main="Leverages for Each Observation")

# 计算 Cook's 距离
cooks_dist <- cooks.distance(model)
barplot(cooks_dist, names.arg=rownames(data), xlab="Observation", ylab="Cook's Distance",
        main="Cook's Distances for Each Observation")