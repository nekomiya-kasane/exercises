cmake_minimum_required(VERSION 3.12)

project(assignment)

if(MSVC)
	set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} /Wall /WX")
else()
	set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -Wall -Werror")
endif()

add_executable(newAlphabet "newAlphabet.cpp")

add_executable(changeOfBase "changeOfBase.cpp")
