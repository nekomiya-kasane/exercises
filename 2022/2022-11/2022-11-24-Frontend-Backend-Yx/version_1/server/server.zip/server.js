const express = require('express');
const mysql = require('mysql');
var cors = require('cors')

const routes = require('./routes')
const config = require('./config.json')

const app = express();

// whitelist localhost 3000
app.use(cors({ credentials: true, origin: ['http://localhost:4821'] }));

// Route 1 - register as GET 
app.get('/players', routes.player)

// Route 2 - register as GET 
app.get('/playerCompare', routes.playerCompare)

// Route 3 - top team win/lose againt
app.get('/teamWinLoseMost', routes.teamWinLoseMost)

// Route 3 - top team win/lose againt
app.get('/teamWinRate', routes.teamWinRate)

app.get('/getDriverMostPoints', routes.getDriverMostPoints)

app.get('/get2022Performance', routes.get2022Performance)

app.get('/getBattle', routes.getBattle)

app.get('/getTop10RaceMost', routes.getTop10RaceMost)

app.get('/getTop10LapsMost', routes.getTop10LapsMost)

app.get('/driverLeaderboard', routes.getDriverLeaderboard)

app.get('/constructorLeaderboard', routes.getConstructorLeaderboard)

app.listen(config.server_port, () => {
    console.log(`Server running at http://${config.server_host}:${config.server_port}/`);
});

module.exports = app;
